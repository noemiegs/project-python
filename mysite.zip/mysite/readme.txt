To have the access of our API django:
Go to the terminal write cd and the path to the project directory (here cd mysite) 
Then write the following command:python manage.py runserver
Then we have the link to our site http://127.0.0.1:8000/
To go to the homepage http://127.0.0.1:8000/polls
After that you can click on the page that you want page1 for visualisation and page2 for machine learning  and click to go then it redirect you to the page you have chosen after that you can choose the model that you want to display !
