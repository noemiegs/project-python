from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("page1/", views.index1, name="page1"),
    path("page2/", views.index3, name="page2"),
    path("page1/apply_Model/", views.index2, name="apply_Model_page1"),
    path("page2/apply_Model/", views.index4, name="apply_Model_page2"),  # Changez ici
]
