from django.http import HttpResponse
from django.template import loader
from django.shortcuts import render
from scipy.io import arff
import pandas as pd
import plotly.express as px
import matplotlib
import numpy as np
import seaborn as sns
import scipy.stats as stats
import geopandas as gpd
from geopandas import GeoDataFrame
import plotly.graph_objects as go
from ipywidgets import interact, widgets
from plotly.subplots import make_subplots
from sklearn.impute import SimpleImputer, KNNImputer
from sklearn.linear_model import LinearRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split, GridSearchCV, RandomizedSearchCV
from collections import Counter, OrderedDict
from imblearn.over_sampling import SMOTE
from xgboost import XGBClassifier
from sklearn.svm import SVC
import random
import warnings


def index(request):
    image_path = "pexels-tima-miroshnichenko-7567443.jpg"
    context = {'image_path': image_path}

    return render(request, "template0.html", context)

def index1(request):
    image_path = "serious-jeune-homme-affaires-regardant-rapport-financier-sembler.jpg"
    context = {'image_path': image_path}

    return render(request, "template1.html", context)
def index4(request):
    image_path = None

    if 'model' in request.GET:
        model_choice = request.GET['model']
        if model_choice == 'Model Comparaison':
            image_path = 'WhatsApp Image 2023-11-29 at 17.31.07.jpeg'
        elif model_choice == 'Random forest performance for different n_estimator' :
            image_path = 'WhatsApp Image 2023-11-29 at 17.32.01.jpeg'

        elif model_choice == 'SVC performance for different C values':
            image_path = 'WhatsApp Image 2023-11-29 at 17.32.15.jpeg'
        elif model_choice == 'Model compraison with Standard on values':
            image_path = 'WhatsApp Image 2023-11-29 at 17.32.35.jpeg'


        elif model_choice == 'Model Comparaison with minscaler':
            image_path = 'WhatsApp Image 2023-11-30 at 19.50.38 (1).jpeg'

        elif model_choice == 'Learning Curve':
            image_path = 'WhatsApp Image 2023-11-29 at 18.00.49 (2).jpeg'
        elif model_choice == 'ROC curves':
            image_path = 'WhatsApp Image 2023-11-29 at 18.01.16 (1).jpeg'


    context = {'image_path': image_path}

    return render(request, "template2.html", context)



from django.shortcuts import render

def index3(request):
    image_path = "serious-jeune-homme-affaires-regardant-rapport-financier-sembler.jpg"
    context = {'image_path': image_path}

    return render(request, "template2.html", context)



def scattter3D(df_tot):
    fig = px.scatter_3d(df_tot, x='net_profit / total_assets', y='total_liabilities / total_assets', z='working_capital / total_assets',
                    color='class', symbol='Year', opacity=0.7, size_max=10)
    fig.update_layout(title='Scatter Plot 3D - Bankruptcy factors',
                  scene=dict(xaxis_title='Net Profit / Total Assets',
                              yaxis_title='Total Liabilities / Total Assets',
                              zaxis_title='Working Capital / Total Assets'))
    plot_html=fig.to_html(full_html=False, default_height=500, default_width=700)
    return plot_html
def ternary(df_tot):
    fig = px.scatter_ternary(df_tot, a='total assets / total liabilities', b='sales / total_assets', c='current_assets / short_term_liabilities', color='class', title='Ternary Scatter Plot')
    plot_html=fig.to_html(full_html=False, default_height=500, default_width=700)
    return plot_html
def histo(df_tot):
    fig = px.histogram(df_tot, x='total assets / total liabilities', title='Distribution of Total Assets/Total Liabilities')

    plot_html=fig.to_html(full_html=False, default_height=500, default_width=700)
    return plot_html
def courbe(df_tot):
    fig = px.line(df_tot, x=df_tot.index, y=['net_profit / total_assets', 'total_liabilities / total_assets'], title='Graph in curve for Net Profit and Total Liabilities')
    plot_html=fig.to_html(full_html=False, default_height=500, default_width=700)
    return plot_html
def violon(df_tot):
    col_name = 'total assets / total liabilities'
    fig = px.violin(df_tot, y=col_name, color='class', title=f'Violin plot of total assets / total liabilities by class')
    fig.update_layout(yaxis_title=col_name)
    plot_html=fig.to_html(full_html=False, default_height=500, default_width=700)
    return plot_html

def nuage(df_tot):
    col_facette_1 = 'total assets / total liabilities'
    col_facette_2 = 'gross profit / sales'
    col_facette_3 = 'equity / total_assets'

    fig= px.scatter(df_tot, x=df_tot.index, y=[col_facette_1, col_facette_2, col_facette_3], facet_col="class",title='Faceted scatter plot for multiple variables')
    plot_html=fig.to_html(full_html=False, default_height=500, default_width=700)
    return plot_html

def bubble(df_tot):
    bubble_cols = ['net_profit / total_assets', 'total_liabilities / total_assets']



    fig = px.scatter(df_tot, x=bubble_cols[0], y=bubble_cols[1], color='class',title='Bubble Chart - Comparison between Net Profit, Total Liabilities, and Sales',labels={bubble_cols[0]: 'Net Profit / Total Assets',bubble_cols[1]: 'Total Liabilities / Total Assets'},size_max=50)
    plot_html=fig.to_html(full_html=False, default_height=500, default_width=700)
    return plot_html
def radar(df_tot):
    df_tot['class'] = df_tot['class'].astype(str)

    radar_cols = [
        'net_profit / total_assets',
        'total_liabilities / total_assets',
        'working_capital / total_assets',
        'sales / short-term liabilities',
        'sales / fixed assets'
        ]

    class_names = df_tot['class'].unique()

    fig = go.Figure()

    for class_name in class_names:
        class_data = df_tot[df_tot['class'] == class_name][radar_cols].mean()
        fig.add_trace(go.Scatterpolar(
            r=class_data.tolist() + [class_data[radar_cols[0]]],
            theta=radar_cols + [radar_cols[0]],
            fill='toself',
            name=class_name
            ))


        fig.update_layout(polar=dict(radialaxis=dict(visible=True,),),showlegend=True,title='Radar Chart - Comparing various metrics between classes')
        plot_html=fig.to_html(full_html=False, default_height=500, default_width=700)
        return plot_html

    fig.update_layout(title_text='Diagram Sankey - Flow between Total Assets, Total Liabilities, and Equity')
    plot_html=fig.to_html(full_html=False, default_height=500, default_width=700)
    return plot_html
def camembert(df_tot):
    fig = px.pie(df_tot, names='class', values='total assets / total liabilities',title='Distribution of Total Assets / Total Liabilities by Class')
    plot_html=fig.to_html(full_html=False, default_height=500, default_width=700)
    return plot_html
def violin3(df_tot):
    col_name = '(gross profit + depreciation) / sales'
    fig = px.violin(df_tot, y=col_name, color='class', title=f'Diagram in violin of {col_name} per classes')
    fig.update_layout(yaxis_title=col_name)
    plot_html=fig.to_html(full_html=False, default_height=500, default_width=700)
    return plot_html
def violin4(df_tot):
    col_name = 'total assets / total liabilities'
    fig = px.violin(df_tot, y=col_name, color='class', title=f'Diagram in violin of {col_name} per classes')
    fig.update_layout(yaxis_title=col_name)
    plot_html=fig.to_html(full_html=False, default_height=500, default_width=700)
    return plot_html

def bar2(df_tot):

    class_counts = df_tot[df_tot["class"] == '1'].groupby("Year").size().reset_index(name="Count")


    fig = px.bar(class_counts, x="Year", y="Count", text="Count", labels={"Count": "Number of Class '1'"})
    fig.update_layout(title="Number of Class '1' for Each Year", xaxis_title="Year", yaxis_title="Number of Class '1'")
    plot_html=fig.to_html(full_html=False, default_height=500, default_width=700)
    return plot_html








def density(df_tot):

    fig = px.density_contour(df_tot,x='(equity - share capital) / total assets',y='sales / inventory',color="class" )
    plot_html=fig.to_html(full_html=False, default_height=500, default_width=700)
    return plot_html



def histo2(df_tot):
    fig = px.scatter(df_tot, x='(short-term liabilities *365) / sales', y='operating expenses / total liabilities', marginal_x="histogram", marginal_y="histogram")
    plot_html=fig.to_html(full_html=False, default_height=500, default_width=700)
    return plot_html
def box(df_tot):
    fig = px.box(df_tot, x='class', y='long-term liabilities / equity', color='class',
             labels={'long-term liabilities / equity': 'long-term liabilities / equity'},
             title='long_term_liabilities_to_equity by Class')
    plot_html=fig.to_html(full_html=False, default_height=500, default_width=700)
    return plot_html
def sunburst(df_tot):
    fig = px.sunburst(df_tot, path=['class', 'Year'], values='sales / inventory')
    plot_html=fig.to_html(full_html=False, default_height=500, default_width=700)
    return plot_html
def camembert2(df_tot):
    sales_to_total_assets_by_year = df_tot.groupby('Year')['sales / total_assets'].mean().reset_index()

    fig = px.pie(sales_to_total_assets_by_year,names='Year',values='sales / total_assets',title='Sales Distribution by Total Assets per Year')
    plot_html=fig.to_html(full_html=False, default_height=500, default_width=700)
    return plot_html
def treemap(df_tot):

    fig = px.treemap(df_tot, path=['Year', 'class'], title='Treemap of repartition by Year and Classes')
    plot_html=fig.to_html(full_html=False, default_height=500, default_width=700)
    return plot_html
def treemap2(df_tot):
    fig = px.treemap(df_tot, path=['Year', 'class'], values='total assets / total liabilities',
                 title='Treemap of the Distribution of Total Assets/Total Liabilities Ratio by Year and Class')
    plot_html=fig.to_html(full_html=False, default_height=500, default_width=700)
    return plot_html
def violin2(df_tot):

    col_name = 'net profit / sales'
    fig = px.violin(df_tot, y=col_name, color='class', title=f'Diagram in violin of {col_name} per classes')
    fig.update_layout(yaxis_title=col_name)
    plot_html=fig.to_html(full_html=False, default_height=500, default_width=700)
    return plot_html

def scatterclass(df_tot):

    df_tot["Year"] = df_tot["Year"].astype(int)
    median_net_profit = df_tot.groupby(['Year', 'class'])['net_profit / total_assets'].median().reset_index()

    fig = go.Figure()


    class_0 = median_net_profit[median_net_profit['class'] == '0']
    fig.add_trace(go.Scatter(x=class_0['Year'], y=class_0['net_profit / total_assets'],mode='lines+markers', name='Class 0', line=dict(color='blue')))


    class_1 = median_net_profit[median_net_profit['class'] == '1']
    fig.add_trace(go.Scatter(x=class_1['Year'], y=class_1['net_profit / total_assets'],mode='lines+markers', name='Class 1', line=dict(color='red')))


    fig.update_layout(title='Median of Net Profit over Years for Class 0 and Class 1',xaxis_title='Year', yaxis_title='Median of Net Profit')
    plot_html=fig.to_html(full_html=False, default_height=500, default_width=700)
    return plot_html

def scatterclass2(df_tot):
    df_tot["Year"] = df_tot["Year"].astype(int)
    median_net_profit = df_tot.groupby(['Year', 'class'])['sales / inventory'].median().reset_index()

    fig = go.Figure()


    class_0 = median_net_profit[median_net_profit['class'] == '0']
    fig.add_trace(go.Scatter(x=class_0['Year'], y=class_0['sales / inventory'],mode='lines+markers', name='Class 0', line=dict(color='blue')))


    class_1 = median_net_profit[median_net_profit['class'] == '1']
    fig.add_trace(go.Scatter(x=class_1['Year'], y=class_1['sales / inventory'],mode='lines+markers', name='Class 1', line=dict(color='red')))


    fig.update_layout(title='Median of sales / inventory over Years for Class 0 and Class 1',xaxis_title='Year', yaxis_title='Median of sales / inventory')
    plot_html=fig.to_html(full_html=False, default_height=500, default_width=700)
    return plot_html

def scatterclass3(df_tot):
    df_tot["Year"] = df_tot["Year"].astype(int)

    median_net_profit = df_tot.groupby(['Year', 'class'])['total assets / total liabilities'].median().reset_index()

    fig = go.Figure()


    class_0 = median_net_profit[median_net_profit['class'] == '0']
    fig.add_trace(go.Scatter(x=class_0['Year'], y=class_0['total assets / total liabilities'],mode='lines+markers', name='Class 0', line=dict(color='blue')))


    class_1 = median_net_profit[median_net_profit['class'] == '1']
    fig.add_trace(go.Scatter(x=class_1['Year'], y=class_1['total assets / total liabilities'],mode='lines+markers', name='Class 1', line=dict(color='red')))


    fig.update_layout(title='Median of total assets / total liabilities over Years for Class 0 and Class 1',xaxis_title='Year', yaxis_title='Median of total assets / total liabilities')
    plot_html=fig.to_html(full_html=False, default_height=500, default_width=700)
    return plot_html






def donut(df_tot):
    fig = px.pie(df_tot, names='Year', title='Net Profit Distribution by Year',
             hole=0.4, color='Year',
             color_discrete_sequence=px.colors.qualitative.Set1)


    fig.update_traces(textinfo='percent+label', pull=[0, 0.1],marker=dict(colors=['#FF9999', '#66B2FF', '#99FF99', '#FFCC99']))
    plot_html=fig.to_html(full_html=False, default_height=500, default_width=700)
    return plot_html


def index2 (request):
    df1 = None
    df2 = None
    df3 = None
    df4 = None
    df5 = None

    for year in range(1, 6):
        file_path = f'{year}year.arff'


        data, meta = arff.loadarff(file_path)


        current_df = pd.DataFrame(data)


        if year == 1:
            df1 = current_df
        elif year == 2:
            df2 = current_df
        elif year == 3:
            df3 = current_df
        elif year == 4:
            df4 = current_df
        elif year == 5:
            df5 = current_df
            new_column_names = {
            'Attr1': 'net_profit / total_assets',
            'Attr2': 'total_liabilities / total_assets',
            'Attr3': 'working_capital / total_assets',
            'Attr4': 'current_assets / short_term_liabilities',
            'Attr5': '[(cash + short-term securities + receivables - short-term liabilities) / (operating expenses - depreciation)] * 365',
            'Attr6': 'retained_earnings / total_assets',
            'Attr7': 'EBIT / total_assets',
            'Attr8': 'book_value_of_equity / total_liabilities',
            'Attr9': 'sales / total_assets',
            'Attr10': 'equity / total_assets',
            'Attr11': '(gross profit + extraordinary items + financial expenses) / total assetss',
            'Attr12': 'gross_profit / short_term_liabilities',
            'Attr13': '(gross profit + depreciation) / sales',
            'Attr14': '(gross profit + interest) / total assets',
            'Attr15': '(total liabilities * 365) / (gross profit + depreciation)',
            'Attr16': '(gross profit + depreciation) / total liabilities',
            'Attr17': 'total assets / total liabilities',
            'Attr18': 'gross profit / total assets',
            'Attr19': 'gross profit / sales',
            'Attr20': '(inventory * 365) / sales',
            'Attr21': 'sales (n) / sales (n-1)',
            'Attr22': 'profit on operating activities / total assets',
            'Attr23': 'net profit / sales',
            'Attr24': 'gross profit (in 3 years) / total assets',
            'Attr25': '(equity - share capital) / total assets',
            'Attr26': 'net profit + depreciation) / total liabilities',
            'Attr27': 'profit on operating activities / financial expenses',
            'Attr28': 'working capital / fixed assets',
            'Attr29': 'logarithm of total assets',
            'Attr30': '(total liabilities - cash) / sales',
            'Attr31': '(gross profit + interest) / sales',
            'Attr32': '(current liabilities * 365) / cost of products sold',
            'Attr33': 'operating expenses / short-term liabilities',
            'Attr34': 'operating expenses / total liabilities',
            'Attr35': 'profit on sales / total assets',
            'Attr36': 'total sales / total assets',
            'Attr37': '(current assets - inventories) / long-term liabilities',
            'Attr38': 'constant capital / total assets',
            'Attr39': 'profit on sales / sales',
            'Attr40': '(current assets - inventory - receivables) / short-term liabilities',
            'Attr41': 'total liabilities / ((profit on operating activities + depreciation) * (12/365))',
            'Attr42': 'profit on operating activities / sales',
            'Attr43': 'rotation receivables + inventory turnover in days',
            'Attr44': '(receivables * 365) / sales',
            'Attr45': 'net profit / inventory',
            'Attr46': '(current assets - inventory) / short-term liabilities',
            'Attr47': '(inventory * 365) / cost of products sold',
            'Attr48': 'EBITDA (profit on operating activities - depreciation) / total assets',
            'Attr49': 'EBITDA (profit on operating activities - depreciation) / sales',
            'Attr50': 'current assets / total liabilities',
            'Attr51': 'short-term liabilities / total assets',
            'Attr52': '(short-term liabilities * 365) / cost of products sold)',
            'Attr53': 'equity / fixed assets',
            'Attr54': 'constant capital / fixed assets',
            'Attr55': 'working capital',
            'Attr56': '(sales - cost of products sold) / sales',
            'Attr57': '(current assets - inventory - short-term liabilities) / (sales - gross profit - depreciation)',
            'Attr58': 'total costs /total sales',
            'Attr59': 'long-term liabilities / equity',
            'Attr60': 'sales / inventory',
            'Attr61': 'sales / receivables',
            'Attr62': '(short-term liabilities *365) / sales',
            'Attr63': 'sales / short-term liabilities',
            'Attr64': 'sales / fixed assets',
            'class': 'class'
            }


            df1.rename(columns=new_column_names, inplace=True)
            df2.rename(columns=new_column_names, inplace=True)
            df3.rename(columns=new_column_names, inplace=True)
            df4.rename(columns=new_column_names, inplace=True)
            df5.rename(columns=new_column_names, inplace=True)
            dfs = [df1,df2,df3,df4,df5]
            for i, df in enumerate(dfs, start=1):
                df['Year'] = i
            df_tot = pd.concat(dfs, ignore_index=True)
            #Suppression de la colone a 40% de MV
            col_to_remove = '(current assets - inventories) / long-term liabilities'
            dfs_updated = [df.drop(columns=[col_to_remove]) for df in dfs]
            for df in dfs:
                df.drop(columns=[col_to_remove], inplace=True)
            df_tot = pd.concat(dfs, ignore_index=True)
            missing_percentage = df_tot.isnull().sum() * 100 / df_tot.shape[0]
            cols_under_2_percent = missing_percentage[missing_percentage < 2].index
            df_tot.dropna(subset=cols_under_2_percent, inplace=True)
            median_imputer = SimpleImputer(strategy='median')
            df_tot[['sales / inventory', 'net profit / inventory', 'profit on operating activities / financial expenses']] = median_imputer.fit_transform(df_tot[['sales / inventory','net profit / inventory', 'profit on operating activities / financial expenses']])

            mean_imputer = SimpleImputer(strategy='mean')
            df_tot[['gross profit (in 3 years) / total assets']] = mean_imputer.fit_transform(df_tot[['gross profit (in 3 years) / total assets']])

            knn_imputer = KNNImputer(n_neighbors=5)
            df_tot[['sales (n) / sales (n-1)']] = knn_imputer.fit_transform(df_tot[['sales (n) / sales (n-1)']])
            median_values = median_imputer.statistics_
            mean_value = mean_imputer.statistics_[0]

            imputation_values = {
            'sales / inventory': median_values[0],
            'net profit / inventory': median_values[1],
            'profit on operating activities / financial expenses': median_values[2],
            'gross profit (in 3 years) / total assets': mean_value
            }

            nom_val_chiffre = [
            'net_profit / total_assets',
            'total_liabilities / total_assets',
            'working_capital / total_assets',

            'sales / short-term liabilities',
            'sales / fixed assets',
            'gross_profit / short_term_liabilities',
            '(gross profit + depreciation) / sales',
            '(gross profit + interest) / total assets',
            '(total liabilities * 365) / (gross profit + depreciation)',
            '(gross profit + depreciation) / total liabilities',
            'total assets / total liabilities',

            'gross profit / sales',
            '(inventory * 365) / sales',
            'sales (n) / sales (n-1)',
            'profit on operating activities / total assets',
            'net profit / sales',
            'gross profit (in 3 years) / total assets',
            '(equity - share capital) / total assets',
            'net profit + depreciation) / total liabilities',
            'profit on operating activities / financial expenses',
            'working capital / fixed assets',
            'logarithm of total assets',
            '(total liabilities - cash) / sales',
            '(gross profit + interest) / sales',
            '(current liabilities * 365) / cost of products sold',
            'operating expenses / short-term liabilities',
            'operating expenses / total liabilities',
            'profit on sales / total assets',
            'total sales / total assets',
            'constant capital / total assets',
            'profit on sales / sales',
            '(current assets - inventory - receivables) / short-term liabilities',
            'total liabilities / ((profit on operating activities + depreciation) * (12/365))',
            'profit on operating activities / sales',
            'rotation receivables + inventory turnover in days',
            '(receivables * 365) / sales',
            'net profit / inventory',
            '(inventory * 365) / cost of products sold',
            'EBITDA (profit on operating activities - depreciation) / total assets',
            'EBITDA (profit on operating activities - depreciation) / sales',
            'current assets / total liabilities',
            'short-term liabilities / total assets',
            '(short-term liabilities * 365) / cost of products sold)',
            'equity / fixed assets',
            'constant capital / fixed assets',
            'working capital',
            '(sales - cost of products sold) / sales',
            '(current assets - inventory - short-term liabilities) / (sales - gross profit - depreciation)',
            'total costs /total sales',
            'long-term liabilities / equity',
            'sales / inventory',
            'sales / receivables',
            '(short-term liabilities *365) / sales',
            'sales / short-term liabilities',
            'sales / fixed assets'

            ]

            for i in nom_val_chiffre:
                # On calcule Q1
                q1 = df_tot[i].quantile(q=0.25)
                # On calcule Q3
                q3 = df_tot[i].quantile(q=0.75)
                # On calcule l'écart interquartile (IQR)
                IQR = q3 - q1
                # On Choisis une valeur plus souple pour la borne
                coefficient = 5
                # On calcule la borne inférieure à l'aide du Q1 et de l'écart interquartile
                borne_inf = q1 - coefficient * IQR
                # On calcule la borne supérieure à l'aide du Q3 et de l'écart interquartile
                borne_sup = q3 + coefficient * IQR
                # On garde les valeurs à l'intérieur de la borne inférieure et supérieure
                df_tot = df_tot[(df_tot[i] >= borne_inf) & (df_tot[i] <= borne_sup)]






    template = loader.get_template("template1.html")
    plot_html = None

    if 'model' in request.GET:

        if request.GET['model'] == 'Scatter Plot 3D - Bankruptcy factors':
            plot_html = scattter3D(df_tot)
        elif request.GET['model'] == 'Ternary Scatter Plot':
            plot_html = ternary(df_tot)
        elif request.GET['model'] == 'Distribution of Total Assets/Total Liabilities':
            plot_html = histo(df_tot)
        elif request.GET['model'] == 'Graph in curve for Net Profit and Total Liabilities':
            plot_html = courbe(df_tot)

        elif request.GET['model'] == 'Faceted scatter plot for multiple variables':
            plot_html = nuage(df_tot)

        elif request.GET['model'] == 'Bubble Chart - Comparison between Net Profit, Total Liabilities, and Sales':
            plot_html = bubble(df_tot)
        elif request.GET['model'] == 'Radar Chart - Comparing various metrics between classes':
            plot_html = radar(df_tot)
        elif request.GET['model'] == 'Diagram in violin of net profit / sales per classes':
            plot_html = violin2(df_tot)
        elif request.GET['model'] == 'Diagram in violin of (gross profit + depreciation) / sales per classes':
            plot_html = violin3(df_tot)
        elif request.GET['model'] == 'Diagram in violin of total assets / total liabilities  per classes':
            plot_html = violin4(df_tot)
        #elif request.GET['model'] == 'Number of Class 1 for Each Year':
            #plot_html = bar2(df_tot)
        #elif request.GET['model'] == 'Median of Net Profit over Years for Class 0 and Class 1':
            #plot_html = scatterclass(df_tot)
        #elif request.GET['model'] == 'Median of sales / inventory over Years for Class 0 and Class 1':
            #plot_html = scatterclass2(df_tot)
        #elif request.GET['model'] == 'Median of total assets / total liabilities over Years for Class 0 and Class 1':
            #plot_html = scatterclass3(df_tot)

        elif request.GET['model'] == 'Density contour of (equity - share capital) / total assets and sales / inventory':
            plot_html = density(df_tot)
        elif request.GET['model'] == 'Barplot of(short-term liabilities *365) / sales and operating expenses / total liabilities':
            plot_html = histo2(df_tot)
        elif request.GET['model'] == 'Boxplot-long_term_liabilities_to_equity by Class':
            plot_html = box(df_tot)
        elif request.GET['model'] == 'Sunburst-sales / inventory':
            plot_html = sunburst(df_tot)
        elif request.GET['model'] == 'Sales Distribution by Total Assets per Year':
            plot_html = camembert2(df_tot)
        elif request.GET['model'] == 'Treemap of repartition by Year and Classes':
            plot_html = treemap(df_tot)
        elif request.GET['model'] == 'Treemap of the Distribution of Total Assets/Total Liabilities Ratio by Year and Class':
            plot_html = treemap2(df_tot)
        elif request.GET['model'] == 'Donut-Net Profit Distribution by Year':
            plot_html = donut(df_tot)






    context = {'plot_html': plot_html}

    return HttpResponse(template.render(context, request))
